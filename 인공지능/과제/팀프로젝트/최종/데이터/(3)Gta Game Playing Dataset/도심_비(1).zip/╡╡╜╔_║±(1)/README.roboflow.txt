
GtaObjectionDetection - v1 2022-05-24 9:39pm
==============================

This dataset was exported via roboflow.ai on May 24, 2022 at 12:39 PM GMT

It includes 60 images.
Cars are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 512x512 (Stretch)

No image augmentation techniques were applied.


