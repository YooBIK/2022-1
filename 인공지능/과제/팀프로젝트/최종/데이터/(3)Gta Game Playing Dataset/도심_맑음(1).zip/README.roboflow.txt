
objectdetection - v1 2022-05-25 10:16pm
==============================

This dataset was exported via roboflow.ai on May 25, 2022 at 1:49 PM GMT

It includes 60 images.
Car are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


