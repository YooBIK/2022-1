
AI_Team_Project_GTA - v1 2022-05-24_AI_Team_Project_ObjectDetection
==============================

This dataset was exported via roboflow.ai on May 24, 2022 at 12:02 PM GMT

It includes 61 images.
Cars are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 512x512 (Stretch)

No image augmentation techniques were applied.


