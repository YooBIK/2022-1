import numpy as np
import sys
np.set_printoptions(threshold=sys.maxsize)

class KNN:
    def __init__(self, feature, targets, target_names, k):
        self.feature = feature                       # 훈련에 사용되는 여러 비트맵의 특징들이 담겨있는 2차원 넘파이 배열
        self.targets = targets                       # Test의 실제 값
        self.target_names = target_names             # 0~9 까지 숫자를 기억하고 있는 배열
        self.k = k                                   # knn 알고리즘에서 정의하는 k 값
        self.distances = []                          # 테스트와  데이터의 거리를 저장할 배열
        self.k_cnt_idx = []                          # 거리의 크기로 정렬하고 작은순서의 distances 의 원소의 index를 저장 배열

    def calculate_distance(self, p1, p2):            # 유클리드 거리를 구하기 위한 Method
        return np.sqrt(((p1-p2)**2).sum(axis=1))


    def k_nearest_neighbor(self, testcase):          # 유클리드 거리를 바탕으로 가까운 Neighbor를 저장하는 Method
        self.distances = self.calculate_distance(self.feature, testcase)
        self.k_cnt_idx = (self.distances.argsort())[:self.k]
       

    def majority_vote(self):
        vote = np.zeros(len(self.target_names), dtype='int')
        for i in self.targets[self.k_cnt_idx]:                          #가장 가까운 k개의 숫자를 확인하면서 vote배열의 해당 숫자 index 에 1씩 증가시켜준다
            vote[i] += 1
        
        return self.target_names[np.where(vote == max(vote))[0][0]]     #가장 최대 득표가 나온 target_name을 출력한다.


    def weighted_majority_vote(self):
        vote = np.zeros(len(self.target_names), dtype='float')
        inverse_distance = np.array([float("inf") if (i == 0) else (1 / i) for i in self.distances[self.k_cnt_idx]],dtype=np.float64)
        for target, w in zip(self.targets[self.k_cnt_idx], inverse_distance):        # 각각의 target 에 해당하는 index에 역수로 취해준 가중치를 더해준다
            vote[target] += w
        return np.argmax(vote)                                                       #가장 가중치가 높은 target_names 를 반환한다
