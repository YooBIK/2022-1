import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from knn import KNN

iris = load_iris()
# print(iris)
X = iris.data[:, :4]  # 모든 분꽃들의 특징점을 가져옵니다.
#모든 분꽃들의 특징점중 앞의 두원소만을 일단단가져옵니다
# sepal length (cm)', 'sepal width (cm)' 에 해당되는 속성입니다.
y = iris.target # 모든 분꽃들의 타겟들을 가져옵니다. 타겟들은 0,1,2 와 같은 정수값으로 이루어져 있습니다.


x1_min, x1_max = X[:, 0].min() - .5, X[:, 0].max() + .5
x2_min, x2_max = X[:, 1].min() - .5, X[:, 1].max() + .5
plt.figure(figsize=(8, 6))
# Plot the training points

X = np.array(X,dtype='float')  # 모든 분꽃들의 특징점을 numpy 배열로 치환합니다.
y = np.array(y)  # 모든 분꽃들의 타겟들을 numpy 배열로 치환합니다.
target_names = iris.target_names  # 타겟코드에 대한 분꽃이름을 가져옵니다.

train_feature_idx = [i for i in range(0, len(X)) if ((i -14)%15 ) != 0]
# X배열(전체 분꽃들의 특징점 배열) 중에서 학습훈련에 사용될 분꽃들의 인덱스 번호들을 구합니다


K = [3, 5, 10]
# K로 사용될 값들을 배열에 담아둡니다.

for k in K:
    print("k is ", k)
    for test in range(14, len(X), 15):
        knn = KNN(X[train_feature_idx], y[train_feature_idx], target_names, k)
        # KNN클래스의 knn 인스턴스를 생성자를 통해 생성합니다
        # 생성자의 첫번째 인자 X[train_feature_idx] 아까 계산한 학습에 사용될 분꽃들의 인덱스 번호 배열을 [ ]안에 주어 해당 인덱스들만 넘겨줍니다
        # 두번째 인자 y[train_feature_idx]도 마찬가지로 학습에 사용될 분꽃들만 넘겨질수 있게끔 합니다.

        knn.k_nearest_neighbor(X[test])
        #knn 알고리즘을 통해 현재 test case 와 비교하여 각 거리를 계산하고 거리가 작은순부터 K개 의 특징점을 저장합니다.
        first_guess = knn.majority_vote()
        second_guess = knn.weighted_majority_vote()
        print("[", test // 15 + 1, "'th test case] majority_vote : ", knn.majority_vote(), "  weighted_majority_vote : ",
              knn.weighted_majority_vote(), "  answer :", target_names[y[test]],end="")
        if (target_names[y[test]]!=first_guess) or (target_names[y[test]]!=second_guess):
            print("   [ predict Failure ! ]",end="")

        print("")

        # 해당 testcase에 대하여 majority_vote 와 weighted_majority_vote 를 수행하여 실제 결과와 비교합니다.

    print("")

plt.scatter(X[:, 0], X[:, 1], c=y, cmap=plt.cm.Set1, edgecolor='k')
plt.xlabel('Sepal length')
plt.ylabel('Sepal width')
plt.xlim(x1_min, x1_max)
plt.ylim(x2_min, x2_max)
plt.show()
